#include "Pila.h"
#include "mini_test.h"

// para compilar:$ g++ -g tests.cpp Pila.cpp -o Pila
// para ejecutar con valgrind:$ valgrind --leak-check=full -v ./Pila

void test_vacia() {
  Pila p;
  ASSERT_EQ(p.tamanio(), 0);
}

void test_apilar() {
  // HACER
  ASSERT(false);
}

void test_desapilar() {
  // HACER	
  ASSERT(false);
}

void test_asignacion() {
  // HACER	
  ASSERT(false);
}

int main() {
  RUN_TEST(test_vacia);
  RUN_TEST(test_apilar);
  RUN_TEST(test_desapilar);
  RUN_TEST(test_asignacion);
  // HACER MAS TEST

  return 0;
}
